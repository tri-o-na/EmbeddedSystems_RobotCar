#pragma once

// Change these to your PHONE HOTSPOT credentials (2.4 GHz)
#define WIFI_SSID      "GWiPhone"
#define WIFI_PASSWORD  ""
#define TCP_PORT      80   // use 80 to access from a browser at http://<Pico-IP>/
#define MAX_ROWS      128          // how many rows to keep (ring buffer)
#define MAX_TYPE_LEN  16
#define MAX_MSG_LEN   128