#include "pico/stdlib.h"
#include "motor_encoder.h"
#include "ultrasonic.h"
#include "servo.h"
#include <stdio.h>
#include <math.h>

#define SERVO_PIN 15
#define TRIG_PIN 0
#define ECHO_PIN 1

#define DETECTION_RANGE_CM 17.0
#define OBJECT_EDGE_THRESHOLD 40.0
#define REVERSE_TIME_MS 500
#define BYPASS_TIME_MS 6000
#define SMALL_TURN_TIME_MS 120   // Changed from 360 to 120ms for ~30 degree turn

// Use the same speeds that worked in your old code
#define FORWARD_SPEED 0.03f
#define TURN_SPEED 0.03f
#define REVERSE_SPEED 0.03f

static float get_distance_reading() {
    return get_stable_distance_cm(TRIG_PIN, ECHO_PIN);
}

int main() {
    stdio_init_all();
    sleep_ms(500);
    printf("=== Obstacle Avoidance with Width Calculation ===\n");

    motors_and_encoders_init();
    servo_init(SERVO_PIN);
    setupUltrasonicPins(TRIG_PIN, ECHO_PIN);

    while (true) {
        float center_distance = get_distance_reading();
        printf("DBG: center_distance=%.1f cm\n", center_distance);

        if (center_distance > 0 && center_distance <= DETECTION_RANGE_CM) {
            printf("\n=== OBSTACLE DETECTED at %.1f cm ===\n", center_distance);
            
            // Stop the car
            motors_stop();
            sleep_ms(500);
            printf("DBG: Motors stopped\n");

            // Release GPIO 15 for servo
            encoder_release_pin_for_servo();
            servo_init(SERVO_PIN);
            sleep_ms(100);

            // --- Scan LEFT ---
            int left_detections = 0;
            int left_clear_count = 0;
            float left_width = -1.0f;
            int left_first_pos = -1, left_last_pos = -1;
            float left_first_dist = -1.0f, left_last_dist = -1.0f;
            {
                const int step = 40;
                printf("LEFT SCAN:\n");
                float prev_dist = -1.0f;
                
                for (int pos = 1500; pos <= 2000; pos += step) {
                    servo_set_pulse_us((uint16_t)pos);
                    sleep_ms(300);
                    float d = get_distance_reading();
                    
                    if (prev_dist > 0 && d > 0 && fabsf(d - prev_dist) > 5.0f) {
                        d = (prev_dist + d) / 2.0f;
                    }
                    
                    printf("  pos=%d, dist=%.1f cm", pos, d);
                    
                    if (d > 0 && d < OBJECT_EDGE_THRESHOLD) {
                        if (left_first_pos == -1) {
                            left_first_pos = pos;
                            left_first_dist = d;
                        }
                        left_last_pos = pos;
                        left_last_dist = d;
                        left_detections++;
                        printf(" [OBSTACLE]\n");
                    } else if (d >= OBJECT_EDGE_THRESHOLD || d == -1.0f) {
                        left_clear_count++;
                        printf(" [CLEAR]\n");
                    } else {
                        printf("\n");
                    }
                    
                    prev_dist = d;
                }
                
                // Calculate width
                if (left_first_pos != -1 && left_last_pos != -1 && 
                    left_first_pos != left_last_pos && 
                    left_first_dist > 0 && left_last_dist > 0) {
                    
                    float angle1_deg = ((float)(left_first_pos - 1500) / 10.0f);
                    float angle2_deg = ((float)(left_last_pos - 1500) / 10.0f);
                    float angle_diff_deg = fabsf(angle2_deg - angle1_deg);
                    float angle_diff_rad = angle_diff_deg * M_PI / 180.0f;
                    float avg_dist = (left_first_dist + left_last_dist) / 2.0f;
                    left_width = avg_dist * angle_diff_rad;
                    
                    printf("  LEFT: angle=%.1f°, avg_dist=%.1f cm, WIDTH=%.1f cm\n", 
                           angle_diff_deg, avg_dist, left_width);
                }
                
                printf("  LEFT Summary: %d detections, %d clear, width=%.1f cm\n", 
                       left_detections, left_clear_count, left_width);
            }
            
            servo_move_to_center();
            sleep_ms(500);

            // --- Scan RIGHT ---
            int right_detections = 0;
            int right_clear_count = 0;
            float right_width = -1.0f;
            int right_first_pos = -1, right_last_pos = -1;
            float right_first_dist = -1.0f, right_last_dist = -1.0f;
            {
                const int step = 40;
                printf("RIGHT SCAN:\n");
                float prev_dist = -1.0f;
                
                for (int pos = 1500; pos >= 1000; pos -= step) {
                    servo_set_pulse_us((uint16_t)pos);
                    sleep_ms(300);
                    float d = get_distance_reading();
                    
                    if (prev_dist > 0 && d > 0 && fabsf(d - prev_dist) > 5.0f) {
                        d = (prev_dist + d) / 2.0f;
                    }
                    
                    printf("  pos=%d, dist=%.1f cm", pos, d);
                    
                    if (d > 0 && d < OBJECT_EDGE_THRESHOLD) {
                        if (right_first_pos == -1) {
                            right_first_pos = pos;
                            right_first_dist = d;
                        }
                        right_last_pos = pos;
                        right_last_dist = d;
                        right_detections++;
                        printf(" [OBSTACLE]\n");
                    } else if (d >= OBJECT_EDGE_THRESHOLD || d == -1.0f) {
                        right_clear_count++;
                        printf(" [CLEAR]\n");
                    } else {
                        printf("\n");
                    }
                    
                    prev_dist = d;
                }
                
                // Calculate width
                if (right_first_pos != -1 && right_last_pos != -1 && 
                    right_first_pos != right_last_pos && 
                    right_first_dist > 0 && right_last_dist > 0) {
                    
                    float angle1_deg = ((float)(right_first_pos - 1500) / 10.0f);
                    float angle2_deg = ((float)(right_last_pos - 1500) / 10.0f);
                    float angle_diff_deg = fabsf(angle2_deg - angle1_deg);
                    float angle_diff_rad = angle_diff_deg * M_PI / 180.0f;
                    float avg_dist = (right_first_dist + right_last_dist) / 2.0f;
                    right_width = avg_dist * angle_diff_rad;
                    
                    printf("  RIGHT: angle=%.1f°, avg_dist=%.1f cm, WIDTH=%.1f cm\n", 
                           angle_diff_deg, avg_dist, right_width);
                }
                
                printf("  RIGHT Summary: %d detections, %d clear, width=%.1f cm\n", 
                       right_detections, right_clear_count, right_width);
            }
            
            servo_move_to_center();
            sleep_ms(300);
            motors_stop();
            encoder_reclaim_pin_from_servo();

            // --- Decision Logic: Choose side with SMALLER WIDTH ---
            bool go_left;
            int left_score = 0;
            int right_score = 0;
            
            printf("\n=== DECISION ANALYSIS ===\n");
            printf("LEFT width: %.1f cm, RIGHT width: %.1f cm\n", left_width, right_width);
            
            // Smaller width = easier to bypass (+5 points)
            if (left_width > 0 && right_width > 0) {
                if (left_width < right_width) {
                    left_score += 5;
                    printf("LEFT has SMALLER width (%.1f < %.1f) +5 points\n", left_width, right_width);
                } else if (right_width < left_width) {
                    right_score += 5;
                    printf("RIGHT has SMALLER width (%.1f < %.1f) +5 points\n", right_width, left_width);
                }
            } else if (left_width > 0) {
                left_score += 3;
                printf("Only LEFT has valid width +3 points\n");
            } else if (right_width > 0) {
                right_score += 3;
                printf("Only RIGHT has valid width +3 points\n");
            }
            
            // More clear positions (+2 points)
            if (left_clear_count > right_clear_count) {
                left_score += 2;
                printf("LEFT has more clear space (%d > %d) +2 points\n", left_clear_count, right_clear_count);
            } else if (right_clear_count > left_clear_count) {
                right_score += 2;
                printf("RIGHT has more clear space (%d > %d) +2 points\n", right_clear_count, left_clear_count);
            }
            
            printf("\nFinal Score: LEFT=%d, RIGHT=%d\n", left_score, right_score);
            
            if (left_score > right_score) {
                go_left = true;
                printf("DECISION: Bypass LEFT (smaller width)\n");
            } else if (right_score > left_score) {
                go_left = false;
                printf("DECISION: Bypass RIGHT (smaller width)\n");
            } else {
                go_left = (left_width > 0 && right_width > 0) ? 
                          (left_width <= right_width) : (left_clear_count >= right_clear_count);
                printf("DECISION: Bypass %s (tie-breaker)\n", go_left ? "LEFT" : "RIGHT");
            }

            printf("\n=== Bypass to %s ===\n\n", go_left ? "LEFT" : "RIGHT");

            // --- Execute Bypass (USING WORKING CODE FROM OLD VERSION) ---
            printf("Step 1: Reversing...\n");
            motor_set(REVERSE_SPEED, REVERSE_SPEED);
            sleep_ms(REVERSE_TIME_MS);
            motors_stop();
            sleep_ms(200);

            if (go_left) {
                printf("Step 2: Turning LEFT...\n");
                motor_set(-TURN_SPEED, TURN_SPEED);
                sleep_ms(SMALL_TURN_TIME_MS);
                motors_stop();
                sleep_ms(200);

                printf("Step 3: Going straight (bypass)...\n");
                motor_set(-FORWARD_SPEED, -FORWARD_SPEED);
                sleep_ms(BYPASS_TIME_MS);
                motors_stop();
                sleep_ms(200);

                printf("Step 4: Turning RIGHT (resume heading)...\n");
                motor_set(TURN_SPEED, -TURN_SPEED);
                sleep_ms(SMALL_TURN_TIME_MS);
                motors_stop();
                sleep_ms(200);
            } else {
                printf("Step 2: Turning RIGHT...\n");
                motor_set(TURN_SPEED, -TURN_SPEED);
                sleep_ms(SMALL_TURN_TIME_MS);
                motors_stop();
                sleep_ms(200);

                printf("Step 3: Going straight (bypass)...\n");
                motor_set(-FORWARD_SPEED, -FORWARD_SPEED);
                sleep_ms(BYPASS_TIME_MS);
                motors_stop();
                sleep_ms(200);

                printf("Step 4: Turning LEFT (resume heading)...\n");
                motor_set(-TURN_SPEED, TURN_SPEED);
                sleep_ms(SMALL_TURN_TIME_MS);
                motors_stop();
                sleep_ms(200);
            }

            printf("Bypass complete. Waiting for path to clear...\n");
            int wait_count = 0;
            while (get_distance_reading() > 0 && get_distance_reading() <= OBJECT_EDGE_THRESHOLD) {
                motors_stop();
                if (wait_count % 10 == 0) {
                    printf("Waiting for path to clear... (%.1f cm)\n", get_distance_reading());
                }
                wait_count++;
                sleep_ms(100);
                if (wait_count >= 50) {
                    printf("Timeout - resuming anyway\n");
                    break;
                }
            }
            printf("Path clear! Resuming normal operation.\n\n");
        } else {
            // Move forward at normal speed
            motor_set(-FORWARD_SPEED, -FORWARD_SPEED);
        }
        sleep_ms(20);
    }
}